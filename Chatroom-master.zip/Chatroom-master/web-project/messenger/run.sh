#!/bin/bash


DEBUG=message:server npm start
